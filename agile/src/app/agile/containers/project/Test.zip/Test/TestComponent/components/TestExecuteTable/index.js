import TableCouldDragAndDrop from './TableCouldDragAndDrop';

export default TableCouldDragAndDrop;
