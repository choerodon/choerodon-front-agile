import UserHead from './UserHead';

export default UserHead;
