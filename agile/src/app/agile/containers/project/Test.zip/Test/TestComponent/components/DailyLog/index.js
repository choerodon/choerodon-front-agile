import DailyLog from './DailyLog';

export default DailyLog;
