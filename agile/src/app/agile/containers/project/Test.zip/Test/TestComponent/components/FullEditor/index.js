import FullEditor from './FullEditor';

export default FullEditor;
