import EditIssueNarrow from './EditIssueNarrow';

export default EditIssueNarrow;
