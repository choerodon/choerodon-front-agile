import TransformSubIssue from './TransformSubIssue';

export default TransformSubIssue;
