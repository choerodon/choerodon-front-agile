import TableCanDragAndDrop from './TableCanDragAndDrop';

export default TableCanDragAndDrop;
