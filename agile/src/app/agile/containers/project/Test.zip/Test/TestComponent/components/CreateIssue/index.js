import CreateIssue from './CreateIssue';

export default CreateIssue;
