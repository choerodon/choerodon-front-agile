import WYSIWYGEditor from './WYSIWYGEditor';

export default WYSIWYGEditor;
