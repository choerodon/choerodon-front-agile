import CopyIssue from './CopyIssue';

export default CopyIssue;
