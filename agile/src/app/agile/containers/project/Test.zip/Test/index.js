import Test from './TestIndex';

export default Test;
