import IssueStore from './IssueStore';

export default IssueStore;
