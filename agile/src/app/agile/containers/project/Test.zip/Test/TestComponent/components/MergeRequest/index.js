import MergeRequest from './MergeRequest';

export default MergeRequest;
